Work in progress - see <http://forum.jeelabs.net/node/457>

Derived from code by Guido Socher and Pascal Stang, hence under GPL2 license.

The home page for this library is <http://jeelabs.org/ethercard>

You can download this project in either
[zip](https://github.com/jcw/ethercard/zipball/master) or
[tar](https://github.com/jcw/ethercard/tarball/master) formats.

Unpack the archive and rename the result to `EtherCard`.  
Put it in the `libraries` folder in your Arduino sketches area.  
Restart the Arduino IDE to make sure it sees the new files.
